#ifndef WIFIMANAGER_H
#define WIFIMANAGER_H

#include <ESP8266WiFi.h>

class WifiManager {
  public:
    WifiManager(const char* ssid, const char* password);  
    void connect();
    bool isConnected();
    IPAddress getIP();

  private:
    const char* _ssid;
    const char* _password;
};

#endif