#include "WifiManager.h"

/**
 * @param ssid
 * @param password
 */
WifiManager::WifiManager(const char* ssid, const char* password) //
  : _ssid(ssid), _password(password) {}

void WifiManager::connect() {
  Serial.print("Verbinde mit WLAN...");
  WiFi.begin(_ssid, _password);

  int retries = 0;
  while (WiFi.status() != WL_CONNECTED && retries < 30) {  //so lange keine Verbindung besteht, und wir noch keine 30 Versuche unternommen haben
    delay(500);
    Serial.print(".");
    retries++;
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {  // Wenn die Verbindung erfolgreich war
    Serial.println("WLAN verbunden!");  //schreibe in den Serial Monitor
    Serial.print("IP-Adresse: ");       //zeige die IP-Adresse an
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("Verbindung fehlgeschlagen!");  // Wenn die Verbindung fehlgeschlagen ist
  }
}

bool WifiManager::isConnected() {   // Gibt den Verbindungsstatus zurück
  return WiFi.status() == WL_CONNECTED;
}

IPAddress WifiManager::getIP() {  // Gibt die lokale IP-Adresse zurück
  return WiFi.localIP();
}